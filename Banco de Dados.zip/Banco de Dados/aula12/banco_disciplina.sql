use adsa;
create table aluno (
ra int primary key auto_increment,
nome_aluno varchar(40),
bairro varchar (40));

create table disciplina(
id_disciplina int primary key auto_increment,
nome_disciplina varchar(40)

);
create table boletim(
periodo_letivo int,
fk_disciplina int,
foreign key(fk_disciplina) references disciplina (id_disciplina),
fk_aluno int,
foreign key (fk_aluno) references aluno (ra),
primary key(periodo_letivo, fk_aluno, fk_disciplina),
media decimal(4,2),
qtd_faltas int
);

alter table aluno modify column ra int auto_increment, auto_increment = 11001;
desc aluno;
select * from disciplina;
insert into aluno (nome_aluno, bairro)values
('Daniele Oliveira ', 'Guaianases'),
('João Victor  ', 'Itaquera'),
('Ligia Monteiro ', 'Morumbi'),
('Rafael Gomes', 'Penha'),
('Barbara Viera ', 'Carrão');
insert into disciplina (nome_disciplina) values
('Banco de Dados'),
('Arquitetura Computacional'),
('Algoritmo'),
('Socioemocional'),
('Tecnologia da Informação');
select * from aluno;
select * from  boletim;
insert into boletim values
(20192, 1 , 11001 , 7.80 , 4 ),
(20192, 2 , 11001 , 6.90 , 2 ),
(20192, 3 , 11001 , 8.70 , 0 ),
(20192, 4 , 11001 , 7.80 , 0 ),
(20192, 5 , 11001 , 10.00 , 1),
(20192, 1 , 11002 , 6.60 , 0 ),
(20192, 2, 11002 , 4.90 , 0 ),
(20192, 3 , 11002 , 5.20 , 0 ),
(20192, 5, 11003 , 7.00 , 2 ),
(20192, 4 , 11003 , 8.00 , 4 ),
(20192, 1 , 11003 , 9.00 , 1 );
-- 
select al.nome_aluno, disc.nome_disciplina from aluno as al, disciplina as disc , boletim as blt 
where blt.fk_disciplina = disc.id_disciplina and blt.fk_aluno = al.ra;

select al.nome_aluno, disc.nome_disciplina from aluno as al, disciplina as disc , boletim as blt 
where blt.fk_disciplina = disc.id_disciplina and blt.fk_aluno = al.ra and disc.id_disciplina = 2;

select al.nome_aluno, disc.nome_disciplina from aluno as al, disciplina as disc , boletim as blt 
where blt.fk_disciplina = disc.id_disciplina and blt.fk_aluno = al.ra and al.ra = '11001';

select sum(media) from boletim;

select avg(media), avg(qtd_faltas) from boletim;

select sum(media),  sum(qtd_faltas) from boletim;

select min(media), max(media) from boletim;

select min(qtd_faltas) as 'Menor quantidade de faltas' ,max(qtd_faltas)as 'Maior quantidade de faltas' from boletim;

select fk_disciplina ,min(qtd_faltas) as 'Menor quantidade de faltas' ,max(qtd_faltas)as 'Maior quantidade de faltas'  
from boletim group by fk_disciplina;

select fk_aluno ,min(media) as 'Menor media' ,max(media)as 'Maior media'  
from boletim group by fk_aluno;

select media from boletim;

select distinct media from boletim;

select qtd_faltas from boletim;

select distinct qtd_faltas from boletim;

select count(media) as 'Quantidade de medias' from boletim;

select count(distinct media) as 'Quantidade de medias' from boletim;




