create database musica;
use musica;
create table musica (
idMusica int primary key auto_increment,
titulo varchar (40),
artista varchar (40),
genero varchar (40));
insert into musica (titulo, artista, genero) values ('bebi liguei', 'marilia', 'sertanejo'),
('vou te que superar', 'matheus e kauan' , 'sertanejo universitario'), ( 'sofro onde eu quiser' , 'yasmim', 'pop'),
('cafe', 'vitao', 'rock'), ('apaixonadinha', 'marilia', 'sertanejo'), ('quarta cadeira', 'matheus e kauan' , 'sertanejo universitario'),
('suas linhas', 'carol', 'rock'), ('Pessimo Negocio', 'Dilsinho', 'Pagode'), ('Pouco a Pouco',' Dilsinho', 'Pagode') ;
select * from musica;
select titulo,artista from musica;
select * from musica where genero = 'sertanejo';
select * from musica where artista = 'Dilsinho';
select * from musica order by TITULO;
select * from musica order by artista desc;
select * from musica where titulo like ('P%');
select * from musica where artista like ('%o');
select * from musica where genero like ('%e_%');
select * from musica where titulo like ('%_d%');
update musica set genero = 'viva' where idMusica = 5 ;
select * from musica;
alter table musica modify titulo varchar (50);
describe musica;
delete from  musica where idMusica = 4;
drop table musica;



