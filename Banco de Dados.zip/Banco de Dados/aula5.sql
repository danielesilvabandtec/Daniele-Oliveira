create database alunos;
use alunos;
create table alunos (
idAluno int primary key auto_increment,
nome varchar (40),
email varchar (40));
create table notebook (
cod_not int primary key auto_increment,
fab varchar (40),
modelo varchar (40));
create table log_not(
 fk_aluno int,
 foreign key (fk_aluno) references alunos (idAluno),
 fk_not int,
 foreign key (fk_not) references notebook (cod_not)
 );

insert into alunos ( nome, email) values 
('Daniele','Daniele@'),
('Ramao', 'ramao@');
insert into notebook (fab, modelo ) values
('dell', 'xxx'),
('lenovo', '330');
select nome from alunos as al, notebook as notb where al.idAluno = notb.fk_aluno;
select nome from alunos;
select * from alunos as al, notebook as notb where al.idAluno = notb.fk_aluno;
drop table notebook;
insert into log_not (fk_aluno, fk_not) values
(1, 1),
(2,2);
select * from alunos;
select * from  notebook;
select al.nome, nt.modelo from alunos as al, log_not as ln, notebook as nt where al.idAluno = ln.fk_aluno and ln.fk_not = 1;
update alunos set nome = 'Maria' where idAluno = 3;
update alunos set nome = 'Joao' where idAluno =4;
select * from alunos;
select * from log_not;
update alunos set email = 'Maria@' where idAluno = 3;
update alunos set email = 'joao@' where idAluno = 4;
select * from  alunos as al, log_not as ln, notebook as nt where al.idAluno = ln.fk_aluno and ln.fk_not;
