create database aula_cinco;
use aula_cinco;
create table atleta (
idAtleta int primary key auto_increment,
nome varchar (40),
modalidade varchar (40),
qtdMedalhas int
);
insert into atleta (nome, modalidade, qtdMedalhas) values 
('Neymar', 'futebol', 3),
('Marta', 'futebol', 2 ),
('Shaquille', 'basquete', 4 ),
('Fabiano', 'volei', 1 ),
('Jorge', 'corrida', 2 );
create table pais (
id_pais int primary key auto_increment ,
nomePais varchar (40),
capital varchar (40));
insert into pais (nomePais, capital) values
('Brasil', 'distrito ederal'),
('Estados unidos', 'Washington'),
('alemanha', 'berlim');
select * from atleta;
select * from pais;
alter table atleta add column fk_pais int;
alter table atleta add foreign key (fk_pais) references pais(id_pais); 
update atleta set fk_pais ='1'where idAtleta = 1;
update atleta set fk_pais ='1'where idAtleta = 2;
update atleta set fk_pais ='2'where idAtleta = 3;
update atleta set fk_pais ='3'where idAtleta = 4;
update atleta set fk_pais ='2'where idAtleta = 5;
select * from atleta as atl, pais as ps where atl.fk_pais = ps.id_pais;
Select * from pais, atleta where atleta.fk_pais = pais.id_pais and pais.nomePais = 'Brasil';






create table musica (
idMusica int primary key auto_increment ,
nome_musica varchar (40),
artista varchar (40),
genero varchar (40),
fkAlbum int,
foreign key (fkAlbum) references album(idAlbum)
);
create table album (
idAlbum int primary key auto_increment,
nome varchar (40),
gravadora varchar (40));
insert into album (nome,gravadora) values ('viva', 'redmusic'),
('todos cantam', 'mkmusic'), ('coleguinhas', 'djmusic');
insert into musica (nome_musica, artista, genero, fkAlbum) values ('bebi liguei', 'marilia', 'sertanejo', 2),
('vou te que superar', 'matheus e kauan' , 'sertanejo universitario', 3), ( 'sofro onde eu quiser' , 'yasmim', 'pop', 3),
('cafe', 'vitao', 'rock', 2), ('apaixonadinha', 'marilia', 'sertanejo', 2), ('quarta cadeira', 'matheus e kauan' , 'sertanejo universitario', 3),
('suas linhas', 'carol', 'rock', 2);
select * from musica as msc , album as alb where msc.fkAlbum = alb.idAlbum;
select * from album;
Select * from musica, album where musica.fkAlbum = album.idAlbum and album.nome = 'viva';
Select * from musica, album where musica.fkAlbum = album.idAlbum and album.gravadora = 'mkmusic';
Select * from pais, atleta where atleta.fkpais = pais.idpais and pais.nomepais = 'Brasil';



create table aluno (
ra int primary key ,
nome  varchar (40),
bairro varchar (40));
insert into aluno values
(01191026,'Gabriel Domingos','Jd Sta Edwiges'),
(01191023,'Jennifer Januario','Interlagos'),
(01191037,'Leonardo Melo','Jd Lenise'),
(01191059,'Livia Monteiro','Sao Jose'),
(01191016,'Marcos Paulo','Vila Primavera'),
(01191004,'Luis Fernando','Imirim');
select * from aluno;
create table empresa (
idEmpresa int primary key auto_increment,
nomeEmpresa varchar (40),
bairro varchar (40),
telefone varchar(11));
insert into empresa (nomeEmpresa, bairro, telefone) values
('C6 Bank', 'Morumbi', '97443-7869'),
('Valid', 'JD.São Paulo', '97453-7349'),
('Stefanni', 'Santana', '91243-2570'),
('Safra', 'Paulista', '99353-7569'),
('Tivit', 'Tatuape', '95189-7080');
select * from empresa;
create table Instituicao_ensino (
idInstituicao int primary key auto_increment,
nomeInstituicao varchar (40) ,
bairro varchar (40));
insert into Instituicao_ensino (nomeInstituicao, bairro) values
('Bandtec', 'Paulista'),
('UNIP', 'Mooca'),
('Federal', 'Santo Andre'),
('São Judas', 'Barra Funda');
select * from instituicao_ensino;
alter table aluno add column fk_empresa int;
alter table aluno add constraint fk_empresa foreign key (fk_empresa) references empresa (idEmpresa);
alter table aluno add column fk_insEnsino int;
alter table aluno add constraint fk_insEnsino foreign key (fk_insEnsino) references Instituicao_ensino (idInstituicao);
update aluno set fk_empresa = 1 ,fk_insEnsino = 1 where ra = '01191026';
update aluno set fk_empresa = 2 ,fk_insEnsino = 1 where ra = '01191023';
update aluno set fk_empresa = 1 ,fk_insEnsino = 1 where ra = '01191037';
update aluno set fk_empresa = 3 ,fk_insEnsino = 3 where ra = '01191059';
update aluno set fk_empresa = 4 ,fk_insEnsino = 4 where ra = '01191016';
update aluno set fk_empresa = 5 ,fk_insEnsino = 2 where ra = '01191004';
select * from aluno as al, instituicao_ensino as ie where al.fk_insEnsino = ie.idInstituicao;
select * from aluno as al, empresa as em, instituicao_ensino as ie where al.fk_empresa = em.idEmpresa and al.fk_insEnsino =ie.idInstituicao and em.nomeEmpresa = 'C6 Bank';
select * from aluno as al, empresa as em, instituicao_ensino as ie where al.fk_empresa = em.idEmpresa and al.fk_insEnsino =ie.idInstituicao and ie.nomeInstituicao= 'Bandtec';
