create database Faculdade;
use Faculdade;
create table professores (
idProfessor int primary key  auto_increment,
nome varchar (40),
cpf int,
especificacao varchar (40),
posicao varchar (40));
create table estudantes (
idEstudante int primary key auto_increment,
nome varchar (40),
CPf int,
data_nasc date ,
pos_graduacao varchar (40));
create table projeto (
idProjeto int primary key auto_increment,
numero_projeto int,
financiador varchar (40),
data_inicial date,
data_final date ,
fk_professor int,
foreign key (fk_professor) references professores (idProfessor),
fk_estudante int,
foreign key (fk_estudante) references estudantes (idEstudante));
create table departamento (
idDepartamento int primary key auto_increment,
numero_dp int,
nome varchar (40),
fk_professores int,
foreign key (fk_professores) references  professores (idProfessor),
fk_estudantes int,
foreign key (fk_estudantes) references estudantes (idEstudante));
insert into estudantes (nome, CPF, data_nasc, pos_graduacao) values
(' Marina Santos', 00000000, 14/03/94, 'Enfermagem'),
(' Janine Barreira', 44444444, 10/10/96, 'Engenharia'),
(' Tatiana Cordeiro', 77777777, 09/11/88, 'Logistica'),
(' Helena Martins', 88888888, 17/01/87, 'Enfermagem'),
(' Felipe Neto', 11111111, 28/02/89, 'Medicina');
insert into professores (nome, CPF,especificacao, posicao) values
( 'Mario Gomes', 88888888, 'Medicina', 'Doutor'),
( 'Paulo Rocha', 77777777, 'Engenharia', 'Mestre'),
( 'Oliver Teixeira', 66666666, 'Filosofo', 'Professor'),
( 'Luana Silva', 11111111, 'Medicina', 'Professora'),
( 'Samanta Santana', 22222222, 'Engenharia', 'Professora');
insert into projeto (numero_projeto, financiador, data_inicial, data_final, fk_professor, fk_estudante) values
( 001 , 'VALID', 12-08-18 , 09-05-19, 1, 2),
( 002 , 'BANDTEC', 07-04-17 , 15-09-18, 2, 5),
( 003 , 'BANDTEC', 12-08-18 , 09-05-19, 3, 4),
( 004 , 'LOGICALIS', 11-06-16 , 23-01-18, 4, 1),
( 005 , 'VALID', 06-11-18 , 09-05-19, 5, 3);
SELECT * FROM professores;
select * from estudantes;

drop table 

