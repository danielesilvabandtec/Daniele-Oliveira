use adsa;
create table pessoacheck (
idPessoa int primary key auto_increment,
nome varchar (40),
sexo char(1),
check(sexo = 'm' or sexo ='f' or sexo = 'n')
);
insert into pessoacheck (nome, sexo)  values
('Daniele Oliveira', 'f');
select * from pessoacheck;
insert into pessoacheck (nome, sexo)  values
('Luzinete Oliveira', 'f'),
('Fabiano Martins','m');
