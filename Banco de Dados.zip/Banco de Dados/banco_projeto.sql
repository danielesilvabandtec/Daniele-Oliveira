create database Daniele_aula_08;
use Daniele_aula_08;
create table acompanhante(
id_acompanhante int primary key auto_increment,
nome varchar (40),
tipo varchar (40)
);
create table projeto (
id_projeto int primary key auto_increment,
nome varchar(40),
desc_projeto varchar(40)
);
create table aluno (
RA int primary key auto_increment,
nome varchar (40),
telefone varchar(9),
fk_acompanhante int,
foreign key (fk_acompanhante) references acompanhante (id_acompanhante),
fk_projeto int,
foreign key (fk_projeto) references projeto (id_projeto),
fk_representante int,
foreign key (fk_representante) references aluno (RA)
)auto_increment = 01192001;
insert into acompanhante (nome, tipo) values
('Mayara Souza','Amiga'),
('Leticia Silva','Namorada'),
('Mateus Oliveira','Irmão'),
('Bianca Camargo','Mãe'),
('Jorde Antonio','Namorado');
insert into projeto (nome, desc_projeto) values
('Inovação','Implantação de Inteligencia Artificial '),
('Tecnologia Avançada','Robôs');
insert into aluno (nome, telefone, fk_acompanhante, fk_projeto) values
('Daniele Oliveira','9999999','2','1'),
('Luana Pires','6666666','1','2'),
('Thiago Silva','8888888','4','1'),
('Tamires Oliveira','0000000','3','1'),
('Lucas Martins','4444444','5','2');
select * from aluno order by RA;
update aluno set fk_representante = '1192006' where RA = '1192009';
update aluno set fk_representante = '1192008' where RA = '1192006';
update aluno set fk_representante = '1192007' where RA = '1192010';
update aluno set fk_representante = '1192006' where RA = '1192007';
update aluno set fk_representante = '1192010' where RA = '1192008';
select a.nome, b.nome from aluno as a, aluno as b where a.ra = b.fk_representante;
select * from acompanhante;
select * from projeto;
select *from aluno as al, projeto as pj where al.fk_projeto = pj.id_projeto;
select al.nome, ac.nome , tipo from aluno as al, acompanhante as ac where al.fk_acompanhante = ac.id_acompanhante;
select * from aluno;
select * from aluno as al, projeto  as pj where al.fk_projeto = pj.id_projeto and pj.nome='Inovação';
select * from aluno as al, acompanhante as ac, projeto as pj
where al.fk_acompanhante = ac.id_acompanhante and al.fk_projeto = pj.id_projeto;
update aluno set nome = 'Daniele Martins' where RA = 1192006;
alter table aluno add column endereco varchar (40);
alter table aluno drop column endereco;
select nome as nomes from aluno;

alter table aluno modify column nome varchar(100);