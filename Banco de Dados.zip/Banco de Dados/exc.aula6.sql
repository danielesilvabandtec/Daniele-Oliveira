create database clientes;
use clientes;

create table dentista (
idDentista int primary key auto_increment,
nomeDentista varchar (40),
bairro varchar (40));
create table paciente (
idPaciente int primary key auto_increment,
nomePaciente varchar (40),
idade int,
fk_dentista int,
foreign key (fk_dentista) references dentista (idDentista));
insert into dentista (nomeDentista, bairro) values
('Lucas Viera', 'Vila Matilde'),
('Maria Sampanho', 'Grajaú'),
('Nicolas Carvalho', 'Murumbi');
insert into paciente (nomePaciente, idade, fk_dentista) values
('Daniele Oliveira', 18, 1),
('Paulo Cruz', 23, 2),
('Vinicius Roberto', 33, 3),
('Fabio Souza', 27,1),
('Roberta Amaral', 34, 2),
('Gabriel Araujo', 15, 3);
select * from paciente;
select * from dentista;
select * from paciente as pc, dentista as dt where pc.fk_dentista = dt.idDentista;
select * from paciente as pc, dentista as dt where pc.fk_dentista = dt.idDentista and dt.bairro like 'Vila%';
update paciente set idade = '25' where idPaciente= '1';
delete from paciente where idPaciente = 3;
select * from paciente;
select nome





