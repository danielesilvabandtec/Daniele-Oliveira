create database pet_shop;
use pet_shop;
create table cliente (
id_Cliente int primary key auto_increment,
Nome_cliente varchar (40),
Telefone int,
sexo char(1),
check (sexo = 'F' or sexo = 'M'),
bairro varchar (40));
create table pet (
id_pet int primary key auto_increment,
tipo varchar (40),
nome_pet varchar (40),
raca varchar (40),
data_nasc date,
fk_cliente int,
foreign key (fk_cliente) references cliente (id_Cliente)
) auto_increment=100;
insert into cliente (Nome_cliente, Telefone, sexo, bairro) values
('Maria Eduarda', 951612328, 'F', 'Jabaquara'),
('Fabiano Martins', 951675145, 'M', 'Guianases'),
('Eduardo Xavier', 951627328, 'M', 'Guarulhos'),
('Vanda Martins', 997536328, 'F', 'Jundiai'),
('Luana Queiroz', 995162328, 'F', 'Pinheiros');
insert into pet (tipo, raca, nome_pet, data_nasc, fk_cliente) values
('Gato','Siamês','Lala', '2012-08-18', 1),
('Hamster','Sirio','Teca', '2018-12-17', 2),
('Cachorro','Yorkshire','Toby', '2019-08-19', 4),
('Gato','vila_lata','Lulu', '2019-08-18', 5),
('Hamster','Chines','Lilinha', '2018-08-18', 2);
select * from cliente ;
select * from pet;
alter table cliente modify Nome_Cliente varchar(45);
select * from pet order by nome_pet;
select * from cliente order by bairro desc;
select *from pet where nome_pet like 'T_%';
select * from cliente where Nome_Cliente like '% Martins';
update cliente set Telefone = '987654321' where id_Cliente = '3';
select * from cliente;
select Nome_Cliente, nome_pet from cliente as cl, pet as pt where pt.fk_cliente = cl.id_Cliente;
select * from cliente where sexo = 'F';
alter table cliente drop column sexo;
delete from pet where id_pet = 103;
select * from pet; 
describe cliente;
drop table pet;
drop table cliente;


