create database atleta;
use atleta;
create table atleta (
idAtleta int primary key auto_increment,
nome varchar (40),
modalidade varchar (40),
qtdMedalhas int
);
select * from atleta;
insert into atleta (nome, modalidade, qtdMedalhas) values 
('Neymar', 'futebol', 3),
('Marta', 'futebol', 2 ),
('Shaquille', 'basquete', 4 ),
('Fabiano', 'volei', 1 ),
('Jorge', 'corrida', 2 );
select * from atleta;
select nome, modalidade,qtdMedalhas from atleta;
select * from atleta where modalidade = 'futebol';
select * from atleta order by modalidade ;
select * from atleta order by qtdMedalhas desc;
select * from atleta where nome like ('F%');
select * from atleta where nome like ('%_t%');
update atleta set qtdMedalhas = 6 where idAtleta = 2;
select * from atleta;
update  atleta set modalidade = 'corrida' where idAtleta =4;
select * from atleta;
delete from atleta where idAtleta =1;
select * from atleta;
drop table atleta;

