create database Filmes;
use filmes;
select * from filmes;
drop table filmes;
create table filmes (
idFilme int primary key auto_increment,
titulo varchar (40),
genero varchar (40),
diretor varchar (40));
insert into filmes ( titulo) values
('Vingadores') ,
('Toy Store' ),
('Velozes e Furiosos') ,
('Matrix') ,
('De repente 30') ,
('Harry Potter') ,
('Aladdin') ,
('Rei Leão') ,
('Homem de Ferro') ,
('Quarteto Fantástico') ,
('Atirador');
select * from filmes;
update filmes set diretor = 'Alfredo' where idFilme = 5;
update filmes set diretor = 'Clores' where idFilme = 6 and idFilme = 11;
update filmes set diretor = 'Marquinhos', genero = 'acao' where idFilme = 4 and idFilme = 9;
update filmes set genero = 'desenhos' where idFilme = 5 and idFilme =6;
select * from filmes;
